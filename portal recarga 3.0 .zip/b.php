<?php

$tk = '5507945866:AAHNHEPDt9CoPJOH5Qq_hQD-MsJF5h7gIRE';
$ci = '5593523190';


?>